Terminal Connection to Car, 2 options:
1) Use an external program
2) Use the "terminal" view:
	Window -> Show View -> Other -> Terminal -> Terminal

Port:	  ???
Baudrate: 115200
Datasize: 8
Parity:   None
Stop Bits:1