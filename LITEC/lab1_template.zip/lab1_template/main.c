// Lab 1
// ENGR-2350
// Name: XXXX
// RIN: XXXX

#include "engr2350_msp432.h"

void GPIOInit();
void TestIO();
void ControlSystem();

uint8_t LEDL = 0; // Two variables to store the state of
uint8_t LEDR = 0; // the LEDs

int main(void)
{

    SysInit();
    GPIOInit();

    printf("\r\n\n"
           "***********\r\n"
           "Lab 1 Start\r\n"
           "***********\r\n");

    while(1){
        TestIO();
        //ControlSystem();
    }
}

void GPIOInit(){
    // Add initializations of inputs and outputs
}

void TestIO(){
    // Add printf statement(s) for testing inputs

    // Example code for testing outputs
    while(1){
        uint8_t cmd = getchar();
        if(cmd == 'a'){
            // Turn LEDL On
        }else if(cmd == 'z'){
            // Turn LEDL Off
        }// ...
    }
}

void ControlSystem(){

}
