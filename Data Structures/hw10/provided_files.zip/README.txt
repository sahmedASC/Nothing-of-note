HOMEWORK 10: JOB PRIORITIZATION


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.
Online resources should have specific URLs

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >


EXTRA CREDIT
As described in the hw.pdf create a new ElegantQueue that can function as a TimeQueue or
as an UrgentQueue. Describe the changes you had to make to main/Job, and how your ElegantQueue
supports both getting the highest urgency Job and getting the earliest Job.


MISC. COMMENTS TO GRADER:  
(optional, please be concise!)


