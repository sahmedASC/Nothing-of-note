HOMEWORK 7: SPATIALLY-EMBEDDED ADJACENCY MAPS


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



ORDER NOTATION ANALYSIS:
Consider the following variables and give the complexity along with a short
justification for each of the functions below:

n: The total number of users
l: The total number of users with a location
d: The total number of users with degree >= 1
m: The total number of connections
p: The number of users that a function will print out

loadConnections():

loadLocations():

printAllUsersWithinDistance():

printDegreesHistogram():

printDegreesOfAll():

printFriendsWithDegree():

printFriendsWithinDistance():

printUsersWithinIDRange():


MISC. COMMENTS TO GRADER:  
(optional, please be concise!)






